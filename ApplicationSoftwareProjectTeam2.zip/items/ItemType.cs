namespace ApplicationSoftwareProjectTeam2.items
{
    public enum ItemType
    {
        Tank,
        Ranged,
        Special,
        Universal,
        Melee
    }
}